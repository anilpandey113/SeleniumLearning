package trainning.WebDriver.day03;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

import trainning.WebDriver.WebDriverFactory;

public class WD03_JQuery {
	private static WebDriver webDriver=null;
	private static String surl="https://jqueryui.com/effect/";
	private static String sBr="CH";
	
	static{
		webDriver=WebDriverFactory.Aut_Init(sBr);
		webDriver.navigate().to(surl);
	}
	
	public static void main(String[] args) {
		String sJQ = "$( \"#effect\" ).effect( \"blind\", \"\", 500, callback );"
				+ "function callback() { setTimeout(function() { $( \"#effect\" )"
				+ ".removeAttr( \"style\" ).hide().fadeIn();}, 1000 )}";
		
		System.out.println(sJQ);
		
		webDriver.switchTo().frame(0);
		JavascriptExecutor javascriptExecutor=(JavascriptExecutor)webDriver;
		
		javascriptExecutor.executeScript(sJQ);
		
		
	}//main


}
