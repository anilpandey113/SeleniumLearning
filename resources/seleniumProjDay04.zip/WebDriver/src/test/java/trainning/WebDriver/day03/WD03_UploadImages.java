package trainning.WebDriver.day03;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import trainning.WebDriver.ThreadSleep;
import trainning.WebDriver.WebDriverFactory;

public class WD03_UploadImages {
	private static WebDriver webDriver=null;
	private static String surl="https://www.google.co.in/?gws_rd=ssl";
	private static String sBr="IE";
	
	static{
		webDriver=WebDriverFactory.Aut_Init(sBr);
		webDriver.navigate().to(surl);
	}
	
	public static void main(String[] args) {
	
		WebElement imageElement=webDriver.findElement(By.xpath("//*[@id='gbw']/div/div/div[1]/div[2]/a"));
		
		imageElement.click();
		ThreadSleep.sleep(5000);
		
		imageElement=webDriver.findElement(By.xpath(".//*[@id='qbi']"));
		imageElement.click();
		ThreadSleep.sleep(5000);

		
		
		imageElement=webDriver.findElement(By.xpath(".//*[@id='qbug']/div/a"));
		imageElement.click();
		ThreadSleep.sleep(5000);

		imageElement=webDriver.findElement(By.xpath(".//*[@id='qbfile']"));
		imageElement.click();
		
		
		ThreadSleep.sleep(2000);
		String sExeFilePath,sImageFilePath,sCmdStmt,sTitle;
		
		if(sBr.equals("FF")){
			sTitle="File Upload";
		}else if(sBr.equals("CH")){
			sTitle="Open";
		}else{
			sTitle="";
		}
		sExeFilePath="C:\\work\\imageuploder.exe";
		sImageFilePath="C:\\work\\Desert.jpg";
		
		// c:\temp\fileUpload.exe "<CmdLine1>" "<Img file>"\
		
//		sCmdStmt=String.format("%s \"%s\" \"%s\"" ,sExeFilePath,sTitle,sImageFilePath);
		sCmdStmt=sExeFilePath+" \""+sTitle+"\" \""+sImageFilePath+"\"";
		
//		command:C:\work\imageuploder.exe "File Upload" "C:\work\Desert.jpg"
//		command:C:\work\imageuploder.exe "File Upload" "C:\work\Desert.jpg"
		
		System.out.println("command:"+sCmdStmt);
		try{
		Runtime.getRuntime().exec(sCmdStmt);
		}catch (Exception e) {
				e.printStackTrace();
		}
		
		
		ThreadSleep.sleep(10000);
		WebDriverFactory.turnOffBrowser();
	}
}
