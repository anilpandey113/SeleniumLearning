package trainning.WebDriver.day04.util;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import trainning.util.PropertyFactory;

public class FlipKartHome_POM {
	private WebElement oSearchEdit;
	private WebElement oSearchBtn;
	private WebElement elctronicsLink;
	private WebElement oAppliances;
	private WebElement oMen;
	private WebElement oWomen;

	
	public FlipKartHome_POM(WebDriver webDriver) {
		super();
		oSearchEdit=webDriver.findElement(By.xpath("//*[@id='container']/div/header/div[1]/div[2]/div/div/div[2]/form/div/div[1]/div/input"));
		oSearchBtn=webDriver.findElement(By.xpath("//*[@id='container']/div/header/div[1]/div[2]/div/div/div[2]/form/div/div[2]/button"));
//		elctronicsLink=webDriver.findElement(By.xpath("//*[@id='container']/div/header/div[2]/div/ul/li[1]/a/span"));
//		oAppliances=webDriver.findElement(By.xpath("/*[@id='container']/div/header/div[2]/div/ul/li[2]/a/span"));
//		oMen=webDriver.findElement(By.xpath("//*[@id='container']/div/header/div[2]/div/ul/li[3]/a/span"));
//		oWomen=webDriver.findElement(By.xpath("//*[@id='container']/div/header/div[2]/div/ul/li[4]/a/span"));
	}
	public FlipKartHome_POM(WebDriver webDriver,boolean flag) {
		super();
		Properties properties=PropertyFactory.getProperties();
		oSearchEdit=webDriver.findElement(By.xpath(properties.getProperty("oSearchEdit")));
		oSearchBtn=webDriver.findElement(By.xpath(properties.getProperty("oSearchBtn")));
	}


	public WebElement getoSearchEdit() {
		return oSearchEdit;
	}


	public WebElement getoSearchBtn() {
		return oSearchBtn;
	}


	public WebElement getElctronicsLink() {
		return elctronicsLink;
	}


	public WebElement getoAppliances() {
		return oAppliances;
	}


	public WebElement getoMen() {
		return oMen;
	}


	public WebElement getoWomen() {
		return oWomen;
	}
	
	
	
	
}
