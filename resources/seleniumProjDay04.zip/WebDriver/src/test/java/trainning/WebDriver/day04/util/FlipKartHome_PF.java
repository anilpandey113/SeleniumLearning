package trainning.WebDriver.day04.util;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.PageFactory;

public class FlipKartHome_PF {

	
	
	@FindBy(xpath="//*[@id='container']/div/header/div[1]/div[2]/div/div/div[2]/form/div/div[1]/div/input")
	private WebElement oSearchEdit;
	
	@FindBy(xpath="//*[@id='container']/div/header/div[1]/div[2]/div/div/div[2]/form/div/div[2]/button")
	private WebElement oSearchBtn;
	
	@FindBy(xpath="//*[@id='container']/div/header/div[2]/div/ul/li[1]/a/span")
	private WebElement elctronicsLink;
	
	@FindBy(xpath="/*[@id='container']/div/header/div[2]/div/ul/li[2]/a/span")
	private WebElement oAppliances;
	
	@FindBy(xpath="//*[@id='container']/div/header/div[2]/div/ul/li[3]/a/span")
	private WebElement oMen;
	
	@FindBy(xpath="//*[@id='container']/div/header/div[2]/div/ul/li[4]/a/span")
	private WebElement oWomen;
	
	@FindBy(xpath="//*[@id='container']/div/div[2]/div[2]/div/div[2]/div/div[1]/div/div[2]")
	private WebElement matchingProduct;
	
	@FindBy(xpath="//*[@id='container']/div/div[2]/div[2]/div/div[2]/div/div[3]/div[1]/div/div")
	private List<WebElement> matchingProductList;

	
	public FlipKartHome_PF(WebDriver webDriver) {
		super();
		PageFactory.initElements(webDriver, this);
	}

	public WebElement getoSearchEdit() {
		return oSearchEdit;
	}


	public WebElement getoSearchBtn() {
		return oSearchBtn;
	}


	public WebElement getElctronicsLink() {
		return elctronicsLink;
	}


	public WebElement getoAppliances() {
		return oAppliances;
	}


	public WebElement getoMen() {
		return oMen;
	}


	public WebElement getoWomen() {
		return oWomen;
	}

	public WebElement getMatchingProduct() {
		return matchingProduct;
	}

	public List<WebElement> getMatchingProductList() {
		return matchingProductList;
	}
	
	
	
	
	

}
