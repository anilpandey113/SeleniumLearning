package trainning.WebDriver.day04.util;

import java.util.List;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import trainning.util.PropertyFactory;

public class FlipKartResultPage {

	private WebElement matchingProduct;
	private List<WebElement> matchingProductList;

	public FlipKartResultPage(WebDriver webDriver) {
		super();
		matchingProduct=webDriver.findElement(By.xpath("//*[@id='container']/div/div[2]/div[2]/div/div[2]/div/div[1]/div/div[2]"));
		matchingProductList=webDriver.findElements(By.xpath("//*[@id='container']/div/div[2]/div[2]/div/div[2]/div/div[3]/div[1]/div/div"));
	}
	public FlipKartResultPage(WebDriver webDriver,boolean flag) {
		super();
		Properties properties=PropertyFactory.getProperties();
		matchingProduct=webDriver.findElement(By.xpath(properties.getProperty("matchingProduct")));
		matchingProductList=webDriver.findElements(By.xpath(properties.getProperty("matchingProductList")));
	}

	public WebElement getMatchingProduct() {
		return matchingProduct;
	}

	public List<WebElement> getMatchingProductList() {
		return matchingProductList;
	}
	
}
