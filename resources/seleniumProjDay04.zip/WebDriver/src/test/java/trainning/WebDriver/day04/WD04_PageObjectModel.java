package trainning.WebDriver.day04;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import trainning.WebDriver.ThreadSleep;
import trainning.WebDriver.WebDriverFactory;
import trainning.WebDriver.day04.util.FlipKartHome_PF;
import trainning.WebDriver.day04.util.FlipKartHome_POM;
import trainning.WebDriver.day04.util.FlipKartResultPage;
import trainning.util.PropertyFactory;

public class WD04_PageObjectModel {
	private static WebDriver webDriver=null;
	private static final String URL="https://www.flipkart.com";
	private static final String BROWSER_INSTANSE="CH";
	
	static{
		webDriver=WebDriverFactory.Aut_Init(BROWSER_INSTANSE);
		webDriver.navigate().to(URL);
	}
	
	
	public static void main(String[] args) {
		try{
			//case1...//POM
//			flipkarExecution();
			
			
//			case2... //Properties file
			//-----flipkarExecutionWithPropertiesFile();
			
//			case...3 //PageFactory
			flipkarExecutionWithProjectFactory();
		}catch(Exception e){
			e.printStackTrace();
		}finally {
			WebDriverFactory.turnOffBrowserWithTime(new Long(10000));
		}
	}
	
	public  static void flipkarExecution(){
		FlipKartHome_POM flipKartHome_POM= new FlipKartHome_POM(webDriver);
		
		flipKartHome_POM.getoSearchEdit().clear();
		flipKartHome_POM.getoSearchEdit().sendKeys("IPhone6s");
		flipKartHome_POM.getoSearchBtn().click();
		
		ThreadSleep.sleep(5000);
		
		FlipKartResultPage flipKartResultPage=new FlipKartResultPage(webDriver);
		
		System.out.println("Total Matching Found:"+flipKartResultPage.getMatchingProduct().getText());
		
		System.out.println(flipKartResultPage.getMatchingProductList().get(0).findElement(By.xpath(".//a")).getText());
		
		
		for (int i = 0; i < flipKartResultPage.getMatchingProductList().size(); i++) {
			System.out.print(i+":---->"+flipKartResultPage.getMatchingProductList().get(i).findElement(By.xpath(".//a/div[2]/div[1]/div[1]")).getText());
			System.out.print("\t\t"+flipKartResultPage.getMatchingProductList().get(i).findElement(By.xpath(".//a/div[2]/div[2]/div[1]/div/div")).getText());
			System.out.println();
		}
		
	}
	public  static void flipkarExecutionWithProjectFactory(){
		FlipKartHome_PF flipKartHome_POM= new FlipKartHome_PF(webDriver);
		
		flipKartHome_POM.getoSearchEdit().clear();
		flipKartHome_POM.getoSearchEdit().sendKeys("IPhone6s");
		
		
		ThreadSleep.sleep(5000);
		flipKartHome_POM.getoSearchEdit().clear();
		flipKartHome_POM.getoSearchEdit().sendKeys("Red mi");
		
		
		flipKartHome_POM.getoSearchBtn().click();
		
		ThreadSleep.sleep(5000);
		
		
		System.out.println("Total Matching Found:"+flipKartHome_POM.getMatchingProduct().getText());
//		
//		System.out.println(flipKartHome_POM.getMatchingProductList().get(0).findElement(By.xpath(".//a")).getText());
		
		
		for (int i = 0; i < flipKartHome_POM.getMatchingProductList().size(); i++) {
			System.out.print(i+":---->"+flipKartHome_POM.getMatchingProductList().get(i).findElement(By.xpath(".//a/div[2]/div[1]/div[1]")).getText());
			System.out.print("\t\t"+flipKartHome_POM.getMatchingProductList().get(i).findElement(By.xpath(".//a/div[2]/div[2]/div[1]/div/div")).getText());
			System.out.println();
		}
		
		webDriver.navigate().back();
		flipKartHome_POM.getElctronicsLink().click();
		
		
	}
	public  static void flipkarExecutionWithPropertiesFile(){
		Properties properties=PropertyFactory.getProperties();
		FlipKartHome_POM flipKartHome_POM= new FlipKartHome_POM(webDriver,true);
		
		flipKartHome_POM.getoSearchEdit().clear();
		flipKartHome_POM.getoSearchEdit().sendKeys("IPhone6s");
		flipKartHome_POM.getoSearchBtn().click();
		
		ThreadSleep.sleep(5000);
		
		FlipKartResultPage flipKartResultPage=new FlipKartResultPage(webDriver);
		
		System.out.println("Total Matching Found:"+flipKartResultPage.getMatchingProduct().getText());
		
		System.out.println(flipKartResultPage.getMatchingProductList().get(0).findElement(By.xpath(".//a")).getText());
		
		
		for (int i = 0; i < flipKartResultPage.getMatchingProductList().size(); i++) {
			System.out.print(i+":---->"+flipKartResultPage.getMatchingProductList().get(i).findElement(By.xpath(properties.getProperty("showResult"))).getText());
			System.out.print("\t\t"+flipKartResultPage.getMatchingProductList().get(i).findElement(By.xpath(properties.getProperty("showResultWithList"))).getText());
			System.out.println();
		}
		
	}
	
}
