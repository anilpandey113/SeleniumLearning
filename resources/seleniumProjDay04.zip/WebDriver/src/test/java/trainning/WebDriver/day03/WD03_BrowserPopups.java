package trainning.WebDriver.day03;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import trainning.WebDriver.ThreadSleep;
import trainning.WebDriver.WebDriverFactory;

public class WD03_BrowserPopups {

	private static WebDriver webDriver=null;
	private static String surl="https://www.w3schools.com/js/js_popup.asp";
	
	static{
		webDriver=WebDriverFactory.Aut_Init("FF");
		webDriver.navigate().to(surl);
	}
	
	public static void main(String[] args) {
		System.out.println("<<<<<<Before click, WebDriver pointed browser info>>>>>>>");
		System.out.println("Tile:"+webDriver.getTitle());
		System.out.println("Hnd NO:"+webDriver.getWindowHandle());
		System.out.println("Number of Browser instanse:"+webDriver.getWindowHandles().size());
		
		
		
//		WebElement element=webDriver.findElement(By.xpath("//*[@id='main']/div[3]/a"));
		WebElement element=webDriver.findElement(By.cssSelector(".w3-btn.w3-margin-bottom"));
		
		element.click();
		
		System.err.println("again checking.");
		
		ThreadSleep.sleep(2000);
		System.out.println("<<<<<<after  click, WebDriver pointed browser info>>>>>>>");
		System.out.println("Tile:"+webDriver.getTitle());
		System.out.println("Hnd NO:"+webDriver.getWindowHandle());
		System.out.println("Number of Browser instanse:"+webDriver.getWindowHandles().size());
		
		
		
		String sNewBrHnd=webDriver.getWindowHandles().toArray()[1].toString();
		
		webDriver.switchTo().window(sNewBrHnd);
		
			System.err.println("\n\n\nagain checking.\n\n\n\n");
		
		ThreadSleep.sleep(2000);
		System.out.println("<<<<<<after  switching to different tab>>>>>>>");
		System.out.println("Tile:"+webDriver.getTitle());
		System.out.println("Hnd NO:"+webDriver.getWindowHandle());
		System.out.println("Number of Browser instanse:"+webDriver.getWindowHandles().size());
		ThreadSleep.sleep(2000);

		
		webDriver.switchTo().frame("iframeResult");
		
		webDriver.findElement(By.xpath("//button")).click();

		WebDriverFactory.existAndCloseAlertBox(10);
		
		
		ThreadSleep.sleep(2000);
		WebDriverFactory.turnOffBrowser();
		
	
	}
}
