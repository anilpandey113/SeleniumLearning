package trainning.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Properties;


public class PropertyFactory {
	private static Properties properties=null;
	
	static{
		
		try{
			properties= new Properties();
			properties.load(new FileInputStream(new File("src/test/resources","xpath.properties")));	
		}catch(Exception e){
			e.printStackTrace();
		}
		
		
	}
	public static Properties getProperties(){
		return properties;
	}
	
	public static void main(String[] args) {
		System.out.println(properties.getProperty("key"));
	}
}
