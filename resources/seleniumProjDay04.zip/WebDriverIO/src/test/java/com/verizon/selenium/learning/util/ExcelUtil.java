package com.verizon.selenium.learning.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtil
{
	private static boolean excelFileCheck(String excelFileName){
		boolean flag=false;
		if(excelFileName!=null &&  excelFileName.trim().length()>0){
			if(excelFileName.endsWith(".xls")|| excelFileName.endsWith("xlsx")){
				if(new File(excelFileName).exists()){
					flag=true;
				}else{
					System.err.println("File doesn't exits:"+excelFileName);
					flag=false;
				}
			}else{
				System.err.println("File extension invalid:"+excelFileName);
				flag=false;
			}
			
		}else{
			System.err.println("Excel file/ sheet name is null or blank");
			flag=false;
		}
		return flag;
	}
	
	public static boolean sheetCheck(String excelFileName, String sheetName) {
		boolean flag = false;
		InputStream inputStream = null;
		Workbook workBook = null;
		Sheet sheet = null;
		if (excelFileCheck(excelFileName)) {
			try {
				inputStream = new FileInputStream(excelFileName);
				workBook = WorkbookFactory.create(inputStream);
				sheet = workBook.getSheet(sheetName);

				if (sheet != null) {
					flag = true;
				} else {
					flag = false;
				}

			} catch (FileNotFoundException e) {
				flag = false;
				e.printStackTrace();
			} catch (EncryptedDocumentException e) {
				flag = false;
				e.printStackTrace();
			} catch (InvalidFormatException e) {
				flag = false;
				e.printStackTrace();
			} catch (IOException e) {
				flag = false;
				e.printStackTrace();
			} finally {
				try {

					if (workBook != null) {
						workBook.close();
					}
					if (inputStream != null) {
						inputStream.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		return flag;
	}
	
	public static int getMaxRow(String excelFileName,String sheetName){
		int noOfRow=0;
		InputStream inputStream = null;
		Workbook workBook = null;
		Sheet sheet = null;
		if(excelFileCheck(excelFileName)&& sheetCheck(excelFileName, sheetName)){
			try {
				inputStream = new FileInputStream(excelFileName);
				workBook = WorkbookFactory.create(inputStream);
				sheet = workBook.getSheet(sheetName);
				noOfRow=sheet.getLastRowNum();
			} catch (Exception e) {
				noOfRow=-1;
				e.printStackTrace();
			}finally {
				try {
					if (workBook != null) {
						workBook.close();
					}
					if (inputStream != null) {
						inputStream.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}else{
			noOfRow=-1;
		}
		return noOfRow;
	}
	public static int getMaxCell(String excelFileName,String sheetName,int rowNo){
		int noOfCell=0;
		InputStream inputStream = null;
		Workbook workBook = null;
		Sheet sheet = null;
		Row row=null;
		int maxRow=getMaxRow(excelFileName, sheetName);
		if(maxRow!=-1 && rowNo<=maxRow){
			
		if(excelFileCheck(excelFileName)&& sheetCheck(excelFileName, sheetName)){
			try {
				inputStream = new FileInputStream(excelFileName);
				workBook = WorkbookFactory.create(inputStream);
				sheet = workBook.getSheet(sheetName);
				row=sheet.getRow(rowNo);
				noOfCell=row.getLastCellNum();
			} catch (Exception e) {
				noOfCell=-1;
				System.err.println("<<<<<<<Failted>>>>>>>>>>");
			}finally {
				try {
					if (workBook != null) {
						workBook.close();
					}
					if (inputStream != null) {
						inputStream.close();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}else{
			noOfCell=-1;
		}
	}else{
		noOfCell=-1;
		System.err.println("Invalid row "+rowNo);
	}
		return noOfCell;
	}
	public static String getCellValue(String excelFileName,String sheetName,int rowNo,int cellNo){
		String value=null;
		int maxRow=getMaxRow(excelFileName, sheetName);
		int maxCell=getMaxCell(excelFileName, sheetName, rowNo);
		InputStream inputStream = null;
		Workbook workBook = null;
		Sheet sheet = null;
		Row row=null;
		Cell cell=null;
		if(maxRow!=-1 && rowNo<=maxRow && maxCell!=-1 && cellNo<=maxCell){
			
			if(excelFileCheck(excelFileName)&& sheetCheck(excelFileName, sheetName)){
				try {
					inputStream = new FileInputStream(excelFileName);
					workBook = WorkbookFactory.create(inputStream);
					sheet = workBook.getSheet(sheetName);
					row=sheet.getRow(rowNo);
					cell=row.getCell(cellNo);
					if(cell!=null){
						value=cell.getStringCellValue();
					}else{
						value="<<<<<<<FAILED cell is null>>>>>>>>>";
						System.err.println("Cell doesn't exits");
					}
				} catch (Exception e) {
					value="<<<<<<<FAILED>>>>>>>>>";
					System.err.println("Fail to get the value row:"+e.getMessage());
					e.printStackTrace();
				}finally {
					try {
						if (workBook != null) {
							workBook.close();
						}
						if (inputStream != null) {
							inputStream.close();
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}else{
				value="<<<<<<<FAILED>>>>>>>>>";
				System.err.println("Fail to load file");
			}
		}else{
			value="<<<<<<<FAILED>>>>>>>>>";
			System.err.println("Fail to get the value row:"+rowNo+"\tcell:"+cellNo);
		}
		return value;
	}

	public static String setCellValue(String excelFileName, String sheetName, int rowNo, int cellNo, String val) {
		String rtVal = null;
		File file = null;
		FileInputStream fileInputStream = null;
		Workbook workbook = null;
		OutputStream outputStream = null;
		Sheet sheet = null;
		Row row = null;
		Cell cell = null;

		try {

			if (!excelFileCheck(excelFileName)) {
				file = new File(excelFileName);
				file.createNewFile();
				fileInputStream = new FileInputStream(file);
				if (excelFileName.endsWith(".xls")) {
					workbook = new HSSFWorkbook();
				} else if (excelFileName.endsWith(".xlsx")) {
					workbook = new XSSFWorkbook();
				} else {
					System.err.println("Provided formet is not correct:" + excelFileName);
					return "Provided Format not a excel format";
				}
				outputStream = new FileOutputStream(file);
				workbook.write(outputStream);
				workbook.close();
				outputStream.close();
				fileInputStream.close();
			}
			file = new File(excelFileName);
			fileInputStream = new FileInputStream(file);
			workbook = WorkbookFactory.create(fileInputStream);
			sheet = workbook.getSheet(sheetName);
			if (sheet == null) {
				workbook.createSheet(sheetName);
				sheet = workbook.getSheet(sheetName);
			}
			row = sheet.createRow(rowNo);
			if (row == null) {
				sheet.createRow(rowNo);
				row = sheet.getRow(rowNo);
			}
			cell = row.getCell(cellNo);
			if (cell == null) {
				row.createCell(cellNo);
				cell = row.getCell(cellNo);
			}
 			cell.setCellValue(val);
			outputStream = new FileOutputStream(file);
			workbook.write(outputStream);

			workbook.close();
			outputStream.close();

		} catch (Exception e) {
			e.printStackTrace();
			System.err.println("File is not creating..." + excelFileName);
			rtVal = "Not updated....";
		}
		return rtVal;
	}
	
}
