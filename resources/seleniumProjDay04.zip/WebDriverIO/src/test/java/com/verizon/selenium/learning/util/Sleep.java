package com.verizon.selenium.learning.util;

public class Sleep {

	public static void sleep(long mill){
		
		try {
			Thread.sleep(mill);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
}
