package trainingSelenium.WebDriverIO;

import com.verizon.selenium.learning.util.ExcelUtil;

public class WorkingWithXls {
 public static void main(String[] args) {
	String excelFileName="C:\\xls_file\\Book2.xlsx";
	String sheetName="Sheet1";
	
	
	System.out.println("new Xls File info");
	
	System.out.println("Total available Row:"+ExcelUtil.getMaxRow(excelFileName, sheetName));
	System.out.println("For 5 Row max available Cell:"+ExcelUtil.getMaxCell(excelFileName, sheetName,5));
	System.out.println("get Cell value:"+ExcelUtil.getCellValue(excelFileName, sheetName, 3, 0));
	System.out.println("get Cell value:"+ExcelUtil.setCellValue(excelFileName, sheetName, 5, 12, "ARvind"));
	
	
	System.out.println("Ended....");
}
}
